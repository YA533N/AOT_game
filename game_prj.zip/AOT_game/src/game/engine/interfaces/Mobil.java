package game.engine.interfaces;

public interface Mobil {
	public int getDistance();
	public void setDistance(int distance);
	public int getSpeed();
	public void setSpeed(int speed);
}
