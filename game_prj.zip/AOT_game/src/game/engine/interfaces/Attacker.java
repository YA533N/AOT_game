package game.engine.interfaces;

public interface Attacker {
	public int getDamage();

}
