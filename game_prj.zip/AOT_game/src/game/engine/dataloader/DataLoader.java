package game.engine.dataloader;

import game.engine.titans.TitanRegistry;

import java.io.IOException;
import java.util.HashMap;

public class DataLoader {
	
	private String TITANS_FILE_NAME;
	private String WEAPONS_FILE_NAME;
	
	public static HashMap<Integer, TitanRegistry> readTitanRegistry() throws IOException{
	
	}
	
}
